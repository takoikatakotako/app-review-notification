import json
import boto3
import uuid
import traceback

def main(slack_token: str, app_id: str):
    # dynamodb = boto3.resource('dynamodb')
    # table = dynamodb.Table('turnip-news-table')
    
    # print(id)
    
    # table.delete_item(
    #     Key={
    #         'newsId': id,
    #     }
    # )
    
    # 

    # Item がすでに存在するかチェック
    dynamo_db = boto3.resource('dynamodb')
    table = dynamo_db.Table('slack-table')
    response = table.get_item(Key={"slackToken": slack_token})

    # Item が無く、新規作成の場合
    if 'Item' not in response:
        item = {
            'status': 'New',
            'failDateTime': [],
            'ios': {
                'appId': {
                    'sentEntryIds': []
                }
            },
            'android': {}
        }
        table.put_item(Item=item)
        return {
            'statusCode': 200,
            'body': '{"message": "新規作成完了"}'
        }


    # すでに作成されている場合亜

    return {
        'statusCode': 200,
        'body': '{"message": "すでに作成されている場合"}'
    }


def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])
        slack_token = body['slackToken']
        app_id = body['appId']
        return main(slack_token, app_id)
    except Exception as e:
        print('-----')
        print('error')
        tb = traceback.format_exc()
        print(tb)
        print('-----')
        return {
            'statusCode': 500,
            'headers': {
            'body': '{"message": "エラーが起きました。"}'
        }
